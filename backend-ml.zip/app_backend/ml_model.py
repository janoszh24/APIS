# app/ml_model.py
import os
import numpy as np
import joblib

MODEL_PATH = os.path.join(os.path.dirname(__file__), "duration_model.pkl")

_duration_model = None

def load_model():
    global _duration_model
    if _duration_model is None:
        if os.path.exists(MODEL_PATH):
            _duration_model = joblib.load(MODEL_PATH)
            print("ML: duration model loaded.")
        else:
            print("ML: duration_model.pkl not found, ML disabled.")
    return _duration_model


def predict_duration_ml(total_qty: int, lines_count: int, task_type: str):
    model = load_model()
    if model is None:
        return None

    t = task_type.upper()
    type_pick = 1.0 if t == "PICK" else 0.0
    type_pack = 1.0 if t == "PACK" else 0.0
    type_load = 1.0 if t == "LOAD" else 0.0

    X = np.array([[float(total_qty), float(lines_count), type_pick, type_pack, type_load]])
    pred = float(model.predict(X)[0])
    return max(pred, 1.0)
