import psycopg2
from psycopg2.extras import RealDictCursor

DATABASE_URL = (
    "postgresql://postgres:"
    "dsTVoWuHSWQbUdKyxJdKXHRVQzTrnffb"
    "@ballast.proxy.rlwy.net:16765/railway"
)

def get_connection():
    # sslmode=require je potrebné pre Railway
    return psycopg2.connect(
        DATABASE_URL,
        cursor_factory=RealDictCursor,
        sslmode="require",
    )
