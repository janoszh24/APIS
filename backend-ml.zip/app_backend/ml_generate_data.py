# app/ml_generate_data.py
import os
import csv
import random

DATA_PATH = os.path.join(os.path.dirname(__file__), "synthetic_tasks.csv")

def generate_synthetic_data(n_orders: int = 300):
    """
    Vygeneruje synteticke data do CSV.
    Kazda "objednavka" dostane 3 tasky: PICK, PACK, LOAD.
    """
    rows = []

    for _ in range(n_orders):
        total_qty = random.randint(1, 200)    # pocet kusov
        lines_count = random.randint(1, 15)   # pocet riadkov objednavky

        for task_type in ["PICK", "PACK", "LOAD"]:
            if task_type == "PICK":
                base = 5
                per_item = 0.5
            elif task_type == "PACK":
                base = 3
                per_item = 0.3
            else:  # LOAD
                base = 8
                per_item = 0.2

            true_duration = base + per_item * total_qty
            noise = random.gauss(0, 2.0)      # nahodny sum
            duration = max(1.0, true_duration + noise)

            rows.append({
                "total_qty": total_qty,
                "lines_count": lines_count,
                "task_type": task_type,
                "duration_min": round(duration, 2),
            })

    return rows


def save_to_csv(rows):
    fieldnames = ["total_qty", "lines_count", "task_type", "duration_min"]
    with open(DATA_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"synthetic data saved to {DATA_PATH}, rows: {len(rows)}")


if __name__ == "__main__":
    data = generate_synthetic_data(n_orders=300)
    save_to_csv(data)
