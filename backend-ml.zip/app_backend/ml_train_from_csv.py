# app/ml_train_from_csv.py
import os
import csv
import numpy as np
from sklearn.linear_model import LinearRegression
import joblib

DATA_PATH = os.path.join(os.path.dirname(__file__), "synthetic_tasks.csv")
MODEL_PATH = os.path.join(os.path.dirname(__file__), "duration_model.pkl")


def load_data_from_csv():
    X = []
    y = []

    with open(DATA_PATH, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_qty = float(row["total_qty"])
            lines_count = float(row["lines_count"])
            task_type = row["task_type"].upper()
            duration_min = float(row["duration_min"])

            type_pick = 1.0 if task_type == "PICK" else 0.0
            type_pack = 1.0 if task_type == "PACK" else 0.0
            type_load = 1.0 if task_type == "LOAD" else 0.0

            X.append([total_qty, lines_count, type_pick, type_pack, type_load])
            y.append(duration_min)

    return np.array(X), np.array(y)


def train_and_save_model():
    X, y = load_data_from_csv()
    if X.size == 0:
        print("ML: no data in CSV, cannot train model.")
        return

    model = LinearRegression()
    model.fit(X, y)

    joblib.dump(model, MODEL_PATH)
    print(f"ML: model trained on {len(y)} samples and saved to {MODEL_PATH}")

    # malý sanity-check
    example = np.array([[50, 5, 1, 0, 0]])  # 50 ks, 5 riadkov, PICK
    pred = model.predict(example)[0]
    print(f"Example prediction (total_qty=50, PICK): {pred:.2f} min")



if __name__ == "__main__":
    train_and_save_model()
