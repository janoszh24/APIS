from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
from fastapi import FastAPI, HTTPException, Request
from .db import get_connection
import jwt

SECRET_KEY = "supersecretjwtkey"  
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


app = FastAPI()

# ---------- MODELY ----------

class Item(BaseModel):
    Id: int
    SKU: str
    Name: str
    Weight: float
    Unit: str

class LoginRequest(BaseModel):
    email: str
    password: str


class LoginResponse(BaseModel):
    token: str
    userId: int
    name: str
    email: str
    role: str

class ItemCreate(BaseModel):
    sku: str
    name: str
    weight: float
    unit: str



class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    role: str  

class RegisterResponse(BaseModel):
    userId: int
    name: str
    email: str
    role: str

class Location(BaseModel):
    id: int
    code: str
    description: str
    zone: str
    capacity: int

class InventoryRow(BaseModel):
    id: int
    itemId: int
    locationId: int
    quantity: int

class InventoryMove(BaseModel):
    itemId: int
    fromLocationId: int
    toLocationId: int
    quantity: int


class Order(BaseModel):
    id: int
    externalOrderId: str
    status: str
    createdAt: datetime
    customerName: str
    customerAddress: str

class OrderCreate(BaseModel):
    externalOrderId: str
    customerName: str
    customerAddress: str
    taskType: str | None = None   


class OrderDelete(BaseModel):
    orderId: int


class OrderStatusUpdate(BaseModel):
    orderId: int
    status: str

class OrderItem(BaseModel):
    id: int
    orderId: int
    itemId: int
    orderedQty: int
    pickedQty: int
    itemSku: str
    itemName: str


class OrderDetail(BaseModel):
    order: Order
    items: List[OrderItem]


class OrderItemCreate(BaseModel):
    itemId: int
    quantity: int


class Task(BaseModel):
    id: int
    orderId: int
    userId: int
    type: str
    status: str
    startedAt: datetime | None = None
    finishedAt: datetime | None = None
    estimatedDurationMin: int | None = None
    actualDurationMin: int | None = None

class TaskAction(BaseModel):
    taskId: int


class Worker(BaseModel):
    id: int
    name: str
    email: str


class InventoryAdd(BaseModel):
    itemId: int
    locationId: int
    quantity: int


# ---------- ENDPOINTY ----------

#uz po pridani db
@app.get("/api/items", response_model=List[Item])
def get_items():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('SELECT "Id", "SKU", "Name", "Weight", "Unit" FROM "Items" ORDER BY "Id"')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in /api/items:", e)
        raise HTTPException(status_code=500, detail="Database error")

@app.get("/debug/users")
def debug_users():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('SELECT "Id","Name","Email","RoleId","CreatedAt" FROM "Users" ORDER BY "Id" DESC LIMIT 5')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB users error: {e}")



@app.get("/debug/roles")
def debug_roles():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('SELECT * FROM "Roles" LIMIT 5')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB roles error: {e}")


@app.post("/api/login", response_model=LoginResponse)
def login(payload: LoginRequest):
    # 1) nájdeme usera podľa emailu
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT u."Id",
                           u."Name",
                           u."Email",
                           u."PasswordHash",
                           u."RoleId",
                           r."Name" AS "RoleName"
                    FROM "Users" u
                    JOIN "Roles" r ON u."RoleId" = r."Id"
                    WHERE u."Email" = %s
                    ''',
                    (payload.email,)
                )
                row = cur.fetchone()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB login error: {e}")

    if not row:
        # používateľ neexistuje
        raise HTTPException(status_code=401, detail="Invalid email or password")

    # 2) jednoduchá kontrola hesla – pre účty s PasswordHash = 'x'
    db_hash = row["PasswordHash"]

    # školský „mechanizmus“: heslo musí byť rovnaké ako hodnota v PasswordHash
    # teda pre Admin One / Worker One / Worker Two je to 'x'
    if payload.password != db_hash:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    user_id = row["Id"]
    name = row["Name"]
    email = row["Email"]
    role_name = row["RoleName"]

    # 3) vytvoríme JWT token
    access_token = create_access_token(
        data={
            "sub": str(user_id),
            "email": email,
            "role": role_name,
        }
    )

    return LoginResponse(
        token=access_token,
        userId=user_id,
        name=name,
        email=email,
        role=role_name,
    )


@app.post("/api/items", response_model=Item)
def create_item(item: ItemCreate):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    INSERT INTO "Items" ("SKU", "Name", "Weight", "Unit")
                    VALUES (%s, %s, %s, %s)
                    RETURNING "Id", "SKU", "Name", "Weight", "Unit"
                    ''',
                    (item.sku, item.name, item.weight, item.unit)
                )
                row = cur.fetchone()
        return row
    except Exception as e:
        print("DB error in POST /api/items:", e)
        raise HTTPException(status_code=500, detail="Database error")


@app.delete("/api/items/{item_id}")
def delete_item(item_id: int):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('DELETE FROM "Items" WHERE "Id" = %s', (item_id,))
                if cur.rowcount == 0:
                    raise HTTPException(status_code=404, detail="Item not found")
        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        print("DB error in DELETE /api/items:", e)
        raise HTTPException(status_code=500, detail="Database error")

from datetime import datetime

@app.post("/api/register", response_model=RegisterResponse)
def register(payload: RegisterRequest):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # 1) nájdeme rolu podľa mena (Admin / Worker)
                cur.execute('SELECT "Id" FROM "Roles" WHERE "Name" = %s', (payload.role,))
                role_row = cur.fetchone()
                if not role_row:
                    raise HTTPException(status_code=400, detail="Role does not exist")

                role_id = role_row["Id"]

                # 2) skontrolujeme, či email už existuje
                cur.execute('SELECT 1 FROM "Users" WHERE "Email" = %s', (payload.email,))
                if cur.fetchone():
                    raise HTTPException(status_code=400, detail="Email already registered")

                # 3) vytvoríme používateľa
                # Musíme doplniť aj CreatedAt, lebo je NOT NULL.
                cur.execute(
                    '''
                    INSERT INTO "Users" ("RoleId", "Name", "Email", "IsEmailVerified", "CreatedAt", "PasswordHash")
                    VALUES (%s, %s, %s, %s, %s, %s)
                    RETURNING "Id"
                    ''',
                    (
                        role_id,
                        payload.name,
                        payload.email,
                        False,
                        datetime.utcnow(),   # 🔹 tu dopĺňame CreatedAt
                        payload.password     # školský projekt – heslo priamo v PasswordHash
                    )
                )
                new_id_row = cur.fetchone()
                new_id = new_id_row["Id"]

        return RegisterResponse(
            userId=new_id,
            name=payload.name,
            email=payload.email,
            role=payload.role
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB register error: {e}")

@app.get("/debug/users-all")
def debug_users_all():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('SELECT "Id","Name","Email","RoleId","CreatedAt" FROM "Users" ORDER BY "Id" DESC')
                rows = cur.fetchall()
                return rows
    except Exception as e:
        return {"error": str(e)}


@app.get("/api/locations", response_model=List[Location])
def get_locations():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT 
                        "Id"        AS id,
                        "Code"      AS code,
                        "Description" AS description,
                        "Zone"      AS zone,
                        "Capacity"  AS capacity
                    FROM "Locations"
                    ORDER BY "Id"
                    '''
                )
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in /api/locations:", e)
        raise HTTPException(status_code=500, detail="Database error")


@app.get("/debug/inventory")
def debug_inventory():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # zobrazíme si surové dáta z tabuľky Inventory
                cur.execute('SELECT * FROM "Inventory" LIMIT 20')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB inventory error: {e}")


@app.get("/api/inventory")
def get_inventory():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT
                        inv."ItemId"      AS "itemId",
                        it."Name"         AS "itemName",
                        inv."LocationId"  AS "locationId",
                        l."Code"          AS "locationCode",
                        inv."Quantity"    AS "quantity"
                    FROM "Inventory" inv
                    JOIN "Items" it     ON it."Id" = inv."ItemId"
                    JOIN "Locations" l  ON l."Id" = inv."LocationId";
                """)
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB inventory error:", e)
        raise HTTPException(status_code=500, detail="DB inventory error")



@app.post("/api/inventory/move")
def move_inventory(move: InventoryMove):
    # jednoduchá validácia vstupu
    if move.quantity <= 0:
        raise HTTPException(status_code=400, detail="Množstvo musí byť väčšie ako 0")
    if move.fromLocationId == move.toLocationId:
        raise HTTPException(status_code=400, detail="Zdrojová a cieľová lokácia nesmie byť rovnaká")

    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # 1) nájdeme riadok na zdrojovej lokácii
                cur.execute(
                    '''
                    SELECT "Id", "Quantity"
                    FROM "Inventory"
                    WHERE "ItemId" = %s AND "LocationId" = %s
                    FOR UPDATE
                    ''',
                    (move.itemId, move.fromLocationId)
                )
                from_row = cur.fetchone()

                if not from_row:
                    raise HTTPException(
                        status_code=400,
                        detail="Na zdrojovej lokácii sa daný tovar nenachádza"
                    )

                current_from_qty = from_row["Quantity"]
                if current_from_qty < move.quantity:
                    raise HTTPException(
                        status_code=400,
                        detail="Nedostatočné množstvo na zdrojovej lokácii"
                    )

                from_inv_id = from_row["Id"]
                new_from_qty = current_from_qty - move.quantity

                # 2) odpočítame zo zdrojovej lokácie (ak je 0, riadok zmažeme)
                if new_from_qty == 0:
                    cur.execute(
                        'DELETE FROM "Inventory" WHERE "Id" = %s',
                        (from_inv_id,)
                    )
                else:
                    cur.execute(
                        'UPDATE "Inventory" SET "Quantity" = %s WHERE "Id" = %s',
                        (new_from_qty, from_inv_id)
                    )

                # 3) pridáme na cieľovú lokáciu (insert alebo update)
                cur.execute(
                    '''
                    SELECT "Id", "Quantity"
                    FROM "Inventory"
                    WHERE "ItemId" = %s AND "LocationId" = %s
                    FOR UPDATE
                    ''',
                    (move.itemId, move.toLocationId)
                )
                to_row = cur.fetchone()

                if not to_row:
                    # ešte tam nie je – vložíme nový riadok
                    cur.execute(
                        '''
                        INSERT INTO "Inventory" ("ItemId", "LocationId", "Quantity")
                        VALUES (%s, %s, %s)
                        ''',
                        (move.itemId, move.toLocationId, move.quantity)
                    )
                else:
                    # už existuje – navýšime množstvo
                    new_to_qty = to_row["Quantity"] + move.quantity
                    cur.execute(
                        'UPDATE "Inventory" SET "Quantity" = %s WHERE "Id" = %s',
                        (new_to_qty, to_row["Id"])
                    )

        return {"status": "ok"}
    except HTTPException:
        # necháme prejsť naše vlastné 400 chyby
        raise
    except Exception as e:
        print("DB error in POST /api/inventory/move:", e)
        raise HTTPException(status_code=500, detail="Database error")

@app.post("/api/inventory/add")
def add_inventory(payload: InventoryAdd):
    """
    Naskladní tovar na danú lokáciu.
    Ak záznam už existuje, navýši množstvo.
    """
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # Skúsime zistiť, či už existuje záznam pre ItemId + LocationId
                cur.execute(
                    '''
                    SELECT "Id", "Quantity"
                    FROM "Inventory"
                    WHERE "ItemId" = %s AND "LocationId" = %s
                    ''',
                    (payload.itemId, payload.locationId)
                )
                row = cur.fetchone()

                if row:
                    # už existuje – navýšime množstvo
                    cur.execute(
                        '''
                        UPDATE "Inventory"
                        SET "Quantity" = "Quantity" + %s
                        WHERE "Id" = %s
                        ''',
                        (payload.quantity, row["Id"])
                    )
                else:
                    # neexistuje – vložíme nový riadok
                    cur.execute(
                        '''
                        INSERT INTO "Inventory" ("ItemId", "LocationId", "Quantity")
                        VALUES (%s, %s, %s)
                        ''',
                        (payload.itemId, payload.locationId, payload.quantity)
                    )

        return {"success": True}
    except Exception as e:
        print("DB error in POST /api/inventory/add:", e)
        raise HTTPException(status_code=500, detail="Database error")


@app.get("/debug/orders")
def debug_orders():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # zobrazíme surové dáta z tabuľky Orders
                cur.execute('SELECT * FROM "Orders" LIMIT 20')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB orders error: {e}")



@app.get("/api/orders", response_model=List[Order])
def get_orders():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT
                        "Id"               AS "id",
                        "ExternalOrderId"  AS "externalOrderId",
                        "Status"           AS "status",
                        "CreatedAt"        AS "createdAt",
                        "CustomerName"     AS "customerName",
                        "CustomerAddress"  AS "customerAddress"
                    FROM "Orders"
                    ORDER BY "CreatedAt" DESC
                    '''
                )
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in /api/orders:", e)
        raise HTTPException(status_code=500, detail="Database error")

from .ml_model import predict_duration_ml

def estimate_task_duration(conn, order_id: int, task_type: str) -> int:
    """
    Odhad trvania ulohy (v minutach).
    1) Skusi ML model natrénovaný na syntetickych datach v CSV.
    2) Ked ML nie je k dispozicii, pouzije povodnu heuristiku.
    """

    with conn.cursor() as cur:
        cur.execute(
            '''
            SELECT
                COALESCE(SUM("OrderedQty"), 0) AS total_qty,
                COUNT(*) AS lines_count
            FROM "OrderItems"
            WHERE "OrderId" = %s
            ''',
            (order_id,)
        )
        row = cur.fetchone()

    total_qty = row["total_qty"] if row and row["total_qty"] is not None else 0
    lines_count = row["lines_count"] if row and row["lines_count"] is not None else 0

    # 1) ML pokus
    ml_pred = predict_duration_ml(total_qty, lines_count, task_type)
    if ml_pred is not None:
        minutes = ml_pred
    else:
        # 2) fallback heuristika
        if task_type == "PICK":
            minutes = 5 + total_qty / 5
        elif task_type == "PACK":
            minutes = 3 + total_qty / 10
        elif task_type == "LOAD":
            minutes = 4 + total_qty / 15
        else:
            minutes = 5 + total_qty / 8

    if minutes < 1:
        minutes = 1

    return int(round(minutes))






@app.post("/api/orders", response_model=Order)
async def create_order(request: Request):
    # 1) prečítame JSON z body
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    external_order_id = data.get("externalOrderId")
    customer_name = data.get("customerName")
    customer_address = data.get("customerAddress")
    task_type_raw = data.get("taskType")      # "PICK" / "PACK" / "LOAD"
    worker_id_raw = data.get("workerId")      # môže byť null

    # 2) jednoduchá validácia vstupu
    if not external_order_id or not customer_name or not customer_address:
        raise HTTPException(status_code=400, detail="Missing required fields")

    task_type = (task_type_raw or "PICK").upper()
    if task_type not in ("PICK", "PACK", "LOAD"):
        task_type = "PICK"

    # worker – ak admin nevyberie, defaultne dáme userId=2
    worker_id = 2
    try:
        if worker_id_raw is not None:
            worker_id = int(worker_id_raw)
    except (TypeError, ValueError):
        # necháme default 2, prípadne by tu mohol byť error 400
        worker_id = 2

    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # 3) vytvor objednávku
                cur.execute(
                    '''
                    INSERT INTO "Orders" ("ExternalOrderId", "Status", "CreatedAt", "CustomerName", "CustomerAddress")
                    VALUES (%s, %s, NOW(), %s, %s)
                    RETURNING
                        "Id"               AS "id",
                        "ExternalOrderId"  AS "externalOrderId",
                        "Status"           AS "status",
                        "CreatedAt"        AS "createdAt",
                        "CustomerName"     AS "customerName",
                        "CustomerAddress"  AS "customerAddress"
                    ''',
                    (
                        external_order_id,
                        "NEW",
                        customer_name,
                        customer_address,
                    )
                )
                row = cur.fetchone()
                new_order_id = row["id"]

                # 4) odhad trvania úlohy
                estimated_minutes = estimate_task_duration(conn, new_order_id, task_type)

                # 5) vytvor task priradený na zvoleného workera
                cur.execute(
                    '''
                    INSERT INTO "Tasks" (
                        "OrderId", "UserId", "Type", "Status",
                        "StartedAt", "FinishedAt",
                        "EstimatedDurationMin", "ActualDurationMin"
                    )
                    VALUES (%s, %s, %s, %s,
                            NULL, NULL,
                            %s, NULL)
                    ''',
                    (new_order_id, worker_id, task_type, "OPEN", estimated_minutes)
                )

        return row

    except HTTPException:
        raise
    except Exception as e:
        print("DB error in POST /api/orders:", e)
        raise HTTPException(status_code=500, detail="Database error")







@app.post("/api/orders/update-status")
def update_order_status(payload: OrderStatusUpdate):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    UPDATE "Orders"
                    SET "Status" = %s
                    WHERE "Id" = %s
                    ''',
                    (payload.status, payload.orderId)
                )

        return {"status": "ok"}
    except Exception as e:
        print("DB error in POST /api/orders/update-status:", e)
        raise HTTPException(status_code=500, detail="Database error")

@app.post("/api/orders/delete")
def delete_order(payload: OrderDelete):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # najprv naviazané údaje (ak existujú)
                cur.execute('DELETE FROM "OrderItems" WHERE "OrderId" = %s', (payload.orderId,))
                cur.execute('DELETE FROM "Tasks"      WHERE "OrderId" = %s', (payload.orderId,))

                # potom samotnú objednávku
                cur.execute('DELETE FROM "Orders" WHERE "Id" = %s', (payload.orderId,))

        return {"status": "ok"}
    except Exception as e:
        print("DB error in POST /api/orders/delete:", e)
        raise HTTPException(status_code=500, detail="Database error")



@app.get("/api/orders/{order_id}", response_model=OrderDetail)
def get_order_detail(order_id: int):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # 1) samotná objednávka
                cur.execute(
                    '''
                    SELECT
                        "Id"              AS "id",
                        "ExternalOrderId" AS "externalOrderId",
                        "Status"          AS "status",
                        "CreatedAt"       AS "createdAt",
                        "CustomerName"    AS "customerName",
                        "CustomerAddress" AS "customerAddress"
                    FROM "Orders"
                    WHERE "Id" = %s
                    ''',
                    (order_id,)
                )
                order_row = cur.fetchone()

                if not order_row:
                    raise HTTPException(status_code=404, detail="Order not found")

                # 2) položky objednávky + prepojenie na Items
                cur.execute(
                    '''
                    SELECT
                        oi."Id"         AS "id",
                        oi."OrderId"    AS "orderId",
                        oi."ItemId"     AS "itemId",
                        oi."OrderedQty" AS "orderedQty",
                        oi."PickedQty"  AS "pickedQty",
                        i."SKU"         AS "itemSku",
                        i."Name"        AS "itemName"
                    FROM "OrderItems" oi
                    JOIN "Items" i ON oi."ItemId" = i."Id"
                    WHERE oi."OrderId" = %s
                    ORDER BY oi."Id"
                    ''',
                    (order_id,)
                )

                item_rows = cur.fetchall()

        return {
            "order": order_row,
            "items": item_rows,
        }
    except HTTPException:
        raise
    except Exception as e:
        print("DB error in GET /api/orders/{id}:", e)
        raise HTTPException(status_code=500, detail="Database error")

@app.post("/api/orders/{order_id}/items")
async def add_order_item(order_id: int, request: Request):
    # 1) načítanie JSON tela
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    # 2) vytiahnutie hodnôt z JSON-u
    try:
        item_id = int(data.get("itemId"))
        ordered_qty = int(data.get("orderedQty"))
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=400,
            detail="itemId a orderedQty sú povinné celé čísla",
        )

    if item_id <= 0 or ordered_qty <= 0:
        raise HTTPException(
            status_code=400,
            detail="itemId a orderedQty musia byť kladné",
        )

    # 3) zápis do DB
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    INSERT INTO "OrderItems" ("OrderId", "ItemId", "OrderedQty", "PickedQty")
                    VALUES (%s, %s, %s, 0)
                    ''',
                    (order_id, item_id, ordered_qty)
                )
                recalc_task_estimates_for_order(conn, order_id)
        return {"status": "ok"}
    except Exception as e:
        print("DB error in POST /api/orders/{order_id}/items:", e)
        raise HTTPException(status_code=500, detail="Database error")


@app.get("/debug/orderitems")
def debug_orderitems():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('SELECT * FROM "OrderItems" LIMIT 5')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB orderitems error: {e}")

@app.get("/api/tasks/{user_id}", response_model=List[Task])
def get_tasks(user_id: int):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT
                        "Id"                    AS "id",
                        "OrderId"               AS "orderId",
                        "UserId"                AS "userId",
                        "Type"                  AS "type",
                        "Status"                AS "status",
                        "StartedAt"             AS "startedAt",
                        "FinishedAt"            AS "finishedAt",
                        "EstimatedDurationMin"  AS "estimatedDurationMin",
                        "ActualDurationMin"     AS "actualDurationMin"
                    FROM "Tasks"
                    WHERE "UserId" = %s
                    ORDER BY "Id" DESC
                    ''',
                    (user_id,)
                )
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in GET /api/tasks/{user_id}:", e)
        raise HTTPException(status_code=500, detail="Database error")



@app.get("/debug/tasks")
def debug_tasks():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute('SELECT * FROM "Tasks" LIMIT 20')
                rows = cur.fetchall()
        return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB tasks error: {e}")


class TaskStartBody(BaseModel):
    taskId: int

@app.post("/api/tasks/start")
def start_task(body: TaskStartBody):
    task_id = body.taskId

    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # zistíme order_id k úlohe
                cur.execute(
                    'SELECT "OrderId" FROM "Tasks" WHERE "Id" = %s',
                    (task_id,)
                )
                row = cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Task not found")

                order_id = row["OrderId"]

                # nastavíme úlohu na IN_PROGRESS
                cur.execute(
                    '''
                    UPDATE "Tasks"
                    SET "Status" = %s,
                        "StartedAt" = NOW()
                    WHERE "Id" = %s
                    ''',
                    ("IN_PROGRESS", task_id)
                )

                # objednávku dáme minimálne na IN_PROGRESS
                cur.execute(
                    '''
                    UPDATE "Orders"
                    SET "Status" = %s
                    WHERE "Id" = %s AND "Status" = %s
                    ''',
                    ("IN_PROGRESS", order_id, "NEW")
                )

        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        print("DB error in POST /api/tasks/start:", e)
        raise HTTPException(status_code=500, detail="Database error")



class TaskFinishBody(BaseModel):
    taskId: int

@app.post("/api/tasks/finish")
def finish_task(body: TaskFinishBody):
    task_id = body.taskId

    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # 1) dokončíme úlohu a necháme DB vypočítať skutočné trvanie v minútach
                cur.execute(
                    '''
                    UPDATE "Tasks"
                    SET "Status" = %s,
                        "FinishedAt" = NOW(),
                        "ActualDurationMin" =
                            CASE
                                WHEN "StartedAt" IS NULL THEN NULL
                                ELSE
                                    ROUND(EXTRACT(EPOCH FROM (NOW() - "StartedAt")) / 60.0)::int
                            END
                    WHERE "Id" = %s
                    RETURNING "OrderId"
                    ''',
                    ("DONE", task_id)
                )
                row = cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Task not found")

                order_id = row["OrderId"]

                # 2) skontrolujeme, či existuje ešte nejaká úloha, ktorá NIE JE DONE
                cur.execute(
                    '''
                    SELECT COUNT(*) AS not_done
                    FROM "Tasks"
                    WHERE "OrderId" = %s
                      AND "Status" <> %s
                    ''',
                    (order_id, "DONE")
                )
                cnt_row = cur.fetchone()
                not_done = cnt_row["not_done"]

                # 3) ak sú všetky DONE -> objednávka DONE, inak aspoň IN_PROGRESS
                if not_done == 0:
                    cur.execute(
                        '''
                        UPDATE "Orders"
                        SET "Status" = %s
                        WHERE "Id" = %s
                        ''',
                        ("DONE", order_id)
                    )
                else:
                    cur.execute(
                        '''
                        UPDATE "Orders"
                        SET "Status" = %s
                        WHERE "Id" = %s AND "Status" = %s
                        ''',
                        ("IN_PROGRESS", order_id, "NEW")
                    )

        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        print("DB error in POST /api/tasks/finish:", e)
        raise HTTPException(status_code=500, detail="Database error")



@app.get("/api/orders/{order_id}/tasks", response_model=List[Task])
def get_order_tasks(order_id: int):
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT
                        "Id"                    AS "id",
                        "OrderId"               AS "orderId",
                        "UserId"                AS "userId",
                        "Type"                  AS "type",
                        "Status"                AS "status",
                        "StartedAt"             AS "startedAt",
                        "FinishedAt"            AS "finishedAt",
                        "EstimatedDurationMin"  AS "estimatedDurationMin",
                        "ActualDurationMin"     AS "actualDurationMin"
                    FROM "Tasks"
                    WHERE "OrderId" = %s
                    ORDER BY "Id"
                    ''',
                    (order_id,)
                )
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in GET /api/orders/{order_id}/tasks:", e)
        raise HTTPException(status_code=500, detail="Database error")

@app.get("/api/tasks-admin", response_model=List[Task])
def get_all_tasks():
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT
                        "Id"                    AS "id",
                        "OrderId"               AS "orderId",
                        "UserId"                AS "userId",
                        "Type"                  AS "type",
                        "Status"                AS "status",
                        "StartedAt"             AS "startedAt",
                        "FinishedAt"            AS "finishedAt",
                        "EstimatedDurationMin"  AS "estimatedDurationMin",
                        "ActualDurationMin"     AS "actualDurationMin"
                    FROM "Tasks"
                    ORDER BY "Id" DESC
                    '''
                )
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in GET /api/tasks-admin:", e)
        raise HTTPException(status_code=500, detail="Database error")

@app.get("/api/workers", response_model=List[Worker])
def get_workers():
    """
    Vráti zoznam používateľov s rolou Worker (RoleId = 2).
    """
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    SELECT
                        "Id"    AS id,
                        "Name"  AS name,
                        "Email" AS email
                    FROM "Users"
                    WHERE "RoleId" = 2
                    ORDER BY "Name"
                    '''
                )
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in GET /api/workers:", e)
        raise HTTPException(status_code=500, detail="Database error")

from fastapi import HTTPException

@app.delete("/api/orders/{order_id}")
def delete_order(order_id: int):
    """
    Zmaže objednávku vrátane položiek a úloh.
    """
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # skontrolujeme, že objednávka existuje
                cur.execute('SELECT "Id" FROM "Orders" WHERE "Id" = %s', (order_id,))
                row = cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Order not found")

                # zmažeme závislé dáta (poradie je dôležité kvôli FK)
                cur.execute('DELETE FROM "Tasks" WHERE "OrderId" = %s', (order_id,))
                cur.execute('DELETE FROM "OrderItems" WHERE "OrderId" = %s', (order_id,))

                # nakoniec samotnú objednávku
                cur.execute('DELETE FROM "Orders" WHERE "Id" = %s', (order_id,))

        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        print("DB error in DELETE /api/orders/{id}:", e)
        raise HTTPException(status_code=500, detail="Database error")

from fastapi import HTTPException

@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int):
    """
    Zmaže úlohu a upraví stav objednávky podľa zvyšných úloh.
    """
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                # zistíme, ku ktorej objednávke patrí úloha
                cur.execute(
                    'SELECT "OrderId" FROM "Tasks" WHERE "Id" = %s',
                    (task_id,)
                )
                row = cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Task not found")

                order_id = row["OrderId"]

                # zmažeme samotnú úlohu
                cur.execute(
                    'DELETE FROM "Tasks" WHERE "Id" = %s',
                    (task_id,)
                )

                # spočítame zvyšné úlohy pri tej istej objednávke
                cur.execute(
                    '''
                    SELECT
                        COUNT(*) AS total,
                        SUM(CASE WHEN "Status" = %s THEN 1 ELSE 0 END) AS done_count
                    FROM "Tasks"
                    WHERE "OrderId" = %s
                    ''',
                    ("DONE", order_id)
                )
                stats = cur.fetchone()
                total = stats["total"]
                done_count = stats["done_count"] or 0

                # podľa toho upravíme stav objednávky
                if total == 0:
                    # žiadne úlohy -> objednávku vrátime na NEW
                    cur.execute(
                        '''
                        UPDATE "Orders"
                        SET "Status" = %s
                        WHERE "Id" = %s
                        ''',
                        ("NEW", order_id)
                    )
                elif done_count == total:
                    # všetky zvyšné sú DONE
                    cur.execute(
                        '''
                        UPDATE "Orders"
                        SET "Status" = %s
                        WHERE "Id" = %s
                        ''',
                        ("DONE", order_id)
                    )
                else:
                    # mix NEW/IN_PROGRESS -> nech je IN_PROGRESS
                    cur.execute(
                        '''
                        UPDATE "Orders"
                        SET "Status" = %s
                        WHERE "Id" = %s
                        ''',
                        ("IN_PROGRESS", order_id)
                    )

        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        print("DB error in DELETE /api/tasks/{id}:", e)
        raise HTTPException(status_code=500, detail="Database error")
    
@app.get("/api/tasks/admin/all")
def get_all_tasks():
    """
    Vráti všetky úlohy pre administrátora.
    """
    try:
        conn = get_connection()
        with conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT
                        "Id"                  AS "id",
                        "OrderId"             AS "orderId",
                        "UserId"              AS "userId",
                        "Type"                AS "type",
                        "Status"              AS "status",
                        "StartedAt"           AS "startedAt",
                        "FinishedAt"          AS "finishedAt",
                        "EstimatedDurationMin" AS "estimatedDurationMin",
                        "ActualDurationMin"    AS "actualDurationMin"
                    FROM "Tasks"
                    ORDER BY "Id"
                """)
                rows = cur.fetchall()
        return rows
    except Exception as e:
        print("DB error in GET /api/tasks/admin/all:", e)
        from fastapi import HTTPException
        raise HTTPException(status_code=500, detail="Database error")

def recalc_task_estimates_for_order(conn, order_id: int):
    """
    Prepočíta EstimatedDurationMin pre všetky úlohy danej objednávky
    na základe aktuálnych OrderItems.
    """
    with conn.cursor() as cur:
        # nájdeme všetky tasky pre danú objednávku
        cur.execute(
            '''
            SELECT "Id", "Type"
            FROM "Tasks"
            WHERE "OrderId" = %s
            ''',
            (order_id,)
        )
        tasks = cur.fetchall()

        for t in tasks:
            task_id = t["Id"]
            task_type = t["Type"]

            # náš ML/heuristický odhad
            new_est = estimate_task_duration(conn, order_id, task_type)

            cur.execute(
                '''
                UPDATE "Tasks"
                SET "EstimatedDurationMin" = %s
                WHERE "Id" = %s
                ''',
                (new_est, task_id)
            )
