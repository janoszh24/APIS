using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Inventory
{
    public class IndexModel : PageModel
    {
        private readonly ApiClientService _api;

        public IndexModel(ApiClientService api)
        {
            _api = api;
        }

        public List<InventoryItemDto> Items { get; set; } = new();
        public List<ItemDto> AllItems { get; set; } = new();
        public List<LocationsDto> AllLocations { get; set; } = new();

        public bool IsAdmin { get; set; }

        public string? ErrorMessage { get; set; }
        public string? SuccessMessage { get; set; }

        // ---- MOVE INPUT ----
        [BindProperty]
        public MoveInputModel MoveInput { get; set; } = new();

        public class MoveInputModel
        {
            public int ItemId { get; set; }
            public int FromLocationId { get; set; }
            public int ToLocationId { get; set; }
            public int Quantity { get; set; }
        }

        // ---- ADD STOCK INPUT ----
        [BindProperty]
        public AddStockInput AddInput { get; set; } = new();

        public class AddStockInput
        {
            public int ItemId { get; set; }
            public int LocationId { get; set; }
            public int Quantity { get; set; }
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            var role = HttpContext.Session.GetString("USER_ROLE");

            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);

            try
            {
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

                // Load inventory
                var respInv = await _api.GetAsync("/api/inventory");
                if (respInv.IsSuccessStatusCode)
                {
                    Items = JsonSerializer.Deserialize<List<InventoryItemDto>>(
                        await respInv.Content.ReadAsStringAsync(), options
                    ) ?? new();
                }

                // Load all items
                var respItems = await _api.GetAsync("/api/items");
                if (respItems.IsSuccessStatusCode)
                {
                    AllItems = JsonSerializer.Deserialize<List<ItemDto>>(
                        await respItems.Content.ReadAsStringAsync(), options
                    ) ?? new();
                }

                // Load all locations
                var respLocs = await _api.GetAsync("/api/locations");
                if (respLocs.IsSuccessStatusCode)
                {
                    AllLocations = JsonSerializer.Deserialize<List<LocationsDto>>(
                        await respLocs.Content.ReadAsStringAsync(), options
                    ) ?? new();
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Chyba pri načítaní skladových dát: {ex.Message}";
            }

            return Page();
        }

        // ---- POST: MOVE STOCK ----
        public async Task<IActionResult> OnPostMoveAsync()
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            if (MoveInput.Quantity <= 0)
            {
                ErrorMessage = "Množstvo musí byť väčšie ako 0.";
                return await OnGetAsync();
            }

            var body = new
            {
                itemId = MoveInput.ItemId,
                fromLocationId = MoveInput.FromLocationId,
                toLocationId = MoveInput.ToLocationId,
                quantity = MoveInput.Quantity
            };

            var resp = await _api.PostAsync("/api/inventory/move", body);

            if (!resp.IsSuccessStatusCode)
                ErrorMessage = "Nepodarilo sa presunúť tovar.";
            else
                SuccessMessage = "Tovar bol úspešne presunutý.";

            return await OnGetAsync();
        }

        // ---- POST: ADD STOCK ----
        public async Task<IActionResult> OnPostAddAsync()
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            var role = HttpContext.Session.GetString("USER_ROLE");

            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            if (!string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                ErrorMessage = "Nemáš oprávnenie naskladniť tovar.";
                return await OnGetAsync();
            }

            if (AddInput.Quantity <= 0)
            {
                ErrorMessage = "Množstvo musí byť väčšie ako 0.";
                return await OnGetAsync();
            }

            var body = new
            {
                itemId = AddInput.ItemId,
                locationId = AddInput.LocationId,
                quantity = AddInput.Quantity
            };

            var resp = await _api.PostAsync("/api/inventory/add", body);

            if (!resp.IsSuccessStatusCode)
                ErrorMessage = "Naskladnenie zlyhalo.";
            else
                SuccessMessage = "Tovar bol úspešne naskladnený.";

            return await OnGetAsync();
        }
    }
}
