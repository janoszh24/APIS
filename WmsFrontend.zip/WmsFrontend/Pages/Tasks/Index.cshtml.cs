using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Tasks
{
    public class TasksIndexModel : PageModel
    {
        private readonly ApiClientService _api;

        public TasksIndexModel(ApiClientService api)
        {
            _api = api;
        }

        public List<TaskDto> Tasks { get; set; } = new();
        public string? ErrorMessage { get; set; }
        public string? SuccessMessage { get; set; }
        public bool IsAdmin { get; set; }
        private void LoadRoleFlags()
        {
            var role = HttpContext.Session.GetString("USER_ROLE");
            IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);
        }


        public async Task<IActionResult> OnGetAsync()
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            var role = HttpContext.Session.GetString("USER_ROLE");

            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");
            LoadRoleFlags();
            IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);
            
            await LoadTasksAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostStartAsync(int taskId)
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            LoadRoleFlags();
            var body = new { taskId };
            var resp = await _api.PostAsync("/api/tasks/start", body);

            if (!resp.IsSuccessStatusCode)
                ErrorMessage = "Nepodarilo sa spustiť úlohu.";
            else
                SuccessMessage = "Úloha bola spustená.";

            await LoadTasksAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostFinishAsync(int taskId)
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");
            LoadRoleFlags();
            var body = new { taskId };
            var resp = await _api.PostAsync("/api/tasks/finish", body);

            if (!resp.IsSuccessStatusCode)
                ErrorMessage = "Nepodarilo sa dokončiť úlohu.";
            else
                SuccessMessage = "Úloha bola dokončená.";

            await LoadTasksAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int taskId)
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            var role = HttpContext.Session.GetString("USER_ROLE");

            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            LoadRoleFlags();
            if (!string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                ErrorMessage = "Nemáš oprávnenie zmazať úlohu.";
                await LoadTasksAsync();
                return Page();
            }

            var resp = await _api.DeleteAsync($"/api/tasks/{taskId}");

            if (!resp.IsSuccessStatusCode)
                ErrorMessage = $"Zmazanie úlohy zlyhalo: {resp.StatusCode}";
            else
                SuccessMessage = "Úloha bola zmazaná.";

            await LoadTasksAsync();
            return Page();
        }

        private async Task LoadTasksAsync()
        {
            try
            {
                var userId = HttpContext.Session.GetString("USER_ID");
                var role = HttpContext.Session.GetString("USER_ROLE");
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

                HttpResponseMessage resp;

                if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase))
                {
                    // admin vidí všetky úlohy (predpokladáme endpoint /api/tasks/all)
                    resp = await _api.GetAsync("/api/tasks/admin/all");
                }
                else
                {
                    // worker vidí len svoje
                    resp = await _api.GetAsync($"/api/tasks/{userId}");
                }

                if (!resp.IsSuccessStatusCode)
                {
                    ErrorMessage = "Nepodarilo sa načítať úlohy.";
                    Tasks = new List<TaskDto>();
                    return;
                }

                var json = await resp.Content.ReadAsStringAsync();
                Tasks = JsonSerializer.Deserialize<List<TaskDto>>(json, options) ?? new List<TaskDto>();
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Chyba pri načítaní úloh: {ex.Message}";
                Tasks = new List<TaskDto>();
            }
        }
    }
}
