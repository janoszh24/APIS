using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Locations;

public class IndexModel : PageModel
{
    private readonly ApiClientService _api;

    public IndexModel(ApiClientService api)
    {
        _api = api;
    }

    public List<LocationsDto> Locations { get; set; } = new();
    public string? ErrorMessage { get; set; }

    public async Task<IActionResult> OnGetAsync()
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
            return RedirectToPage("/Account/Login");

        try
        {
            var resp = await _api.GetAsync("/api/locations");

            if (!resp.IsSuccessStatusCode)
            {
                ErrorMessage = $"Nepodarilo sa načítať lokácie. Status {(int)resp.StatusCode}.";
                return Page();
            }

            var json = await resp.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

            Locations = JsonSerializer.Deserialize<List<LocationsDto>>(json, options)
                         ?? new List<LocationsDto>();
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri načítaní lokácií: {ex.Message}";
        }

        return Page();
    }
}
