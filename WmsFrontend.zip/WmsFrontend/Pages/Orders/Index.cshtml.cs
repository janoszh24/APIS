using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Orders
{
    public class IndexModel : PageModel
    {
        private readonly ApiClientService _api;

        public IndexModel(ApiClientService api)
        {
            _api = api;
        }

        public List<OrderDto> Orders { get; set; } = new();
        public List<WorkerDto> Workers { get; set; } = new();
        public string? ErrorMessage { get; set; }
        public bool IsAdmin { get; set; }

        [BindProperty]
        public NewOrderInput NewOrder { get; set; } = new();

        public class NewOrderInput
        {
            public string ExternalOrderId { get; set; } = "";
            public string CustomerName { get; set; } = "";
            public string CustomerAddress { get; set; } = "";
            public string TaskType { get; set; } = "PICK";
            public int? WorkerId { get; set; }
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            var role = HttpContext.Session.GetString("USER_ROLE");

            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);

            try
            {
                // Load orders
                var resp = await _api.GetAsync("/api/orders");
                if (!resp.IsSuccessStatusCode)
                {
                    ErrorMessage = $"Nepodarilo sa načítať objednávky. Status {resp.StatusCode}";
                    return Page();
                }

                var json = await resp.Content.ReadAsStringAsync();
                var opt = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                Orders = JsonSerializer.Deserialize<List<OrderDto>>(json, opt) ?? new();

                // Load workers only for admin
                if (IsAdmin)
                {
                    var respWorkers = await _api.GetAsync("/api/workers");
                    if (respWorkers.IsSuccessStatusCode)
                    {
                        var wjson = await respWorkers.Content.ReadAsStringAsync();
                        Workers = JsonSerializer.Deserialize<List<WorkerDto>>(wjson, opt) ?? new();
                    }
                    else
                    {
                        ErrorMessage = "Nepodarilo sa načítať workerov.";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Chyba: {ex.Message}";
            }

            return Page();
        }

        public async Task<IActionResult> OnPostCreateAsync()
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            if (!ModelState.IsValid)
            {
                ErrorMessage = "Formulár obsahuje neplatné údaje.";
                return await OnGetAsync();
            }

            try
            {
                var body = new
                {
                    externalOrderId = NewOrder.ExternalOrderId,
                    customerName = NewOrder.CustomerName,
                    customerAddress = NewOrder.CustomerAddress,
                    taskType = NewOrder.TaskType,
                    workerId = NewOrder.WorkerId // NULL allowed
                };

                var resp = await _api.PostAsync("/api/orders", body);

                if (!resp.IsSuccessStatusCode)
                {
                    ErrorMessage = $"Vytvorenie objednávky zlyhalo: {resp.StatusCode}";
                    return await OnGetAsync();
                }

                // refresh
                return RedirectToPage();
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Chyba pri vytváraní objednávky: {ex.Message}";
                return await OnGetAsync();
            }
        }
        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var token = HttpContext.Session.GetString("JWT_TOKEN");
            if (string.IsNullOrEmpty(token))
                return RedirectToPage("/Account/Login");

            try
            {
                var resp = await _api.DeleteAsync($"/api/orders/{id}");
                if (!resp.IsSuccessStatusCode)
                {
                    ErrorMessage = $"Zmazanie objednávky zlyhalo: {resp.StatusCode}";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Chyba pri mazaní objednávky: {ex.Message}";
            }

            // znova načítame dáta
            return await OnGetAsync();
        }

    }
}
