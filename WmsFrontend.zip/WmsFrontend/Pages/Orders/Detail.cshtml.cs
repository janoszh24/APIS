using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Orders;

public class DetailModel : PageModel
{
    private readonly ApiClientService _api;

    public DetailModel(ApiClientService api)
    {
        _api = api;
    }

    public OrderDto? Order { get; set; }
    public List<OrderItemDto> Items { get; set; } = new();
    public List<TaskDto> OrderTasks { get; set; } = new();

    public List<ItemDto> ItemsCatalog { get; set; } = new();

    public string? ErrorMessage { get; set; }
    public string? SuccessMessage { get; set; }

    public bool IsAdmin { get; set; }

    public class NewOrderItemModel
    {
        [Required(ErrorMessage = "Vyber položku.")]
        [Display(Name = "Položka")]
        public int ItemId { get; set; }

        [Required(ErrorMessage = "Zadaj množstvo.")]
        [Range(1, int.MaxValue, ErrorMessage = "Množstvo musí byť aspoň 1.")]
        [Display(Name = "Množstvo")]
        public int OrderedQty { get; set; }
    }

    [BindProperty]
    public NewOrderItemModel NewItem { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
            return RedirectToPage("/Account/Login");

        LoadRole();
        await LoadDataAsync(id);
        return Page();
    }

    public async Task<IActionResult> OnPostAddItemAsync(int id)
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
            return RedirectToPage("/Account/Login");

        LoadRole();

        if (!IsAdmin)
        {
            ErrorMessage = "Nemáš oprávnenie pridávať položky do objednávky.";
            await LoadDataAsync(id);
            return Page();
        }

        if (!ModelState.IsValid)
        {
            await LoadDataAsync(id);
            return Page();
        }

        try
        {
            var body = new
            {
                itemId = NewItem.ItemId,
                orderedQty = NewItem.OrderedQty
            };

            var resp = await _api.PostAsync(
                $"/api/orders/{id}/items",
                body
            );

            if (!resp.IsSuccessStatusCode)
            {
                ErrorMessage = "Pridanie položky zlyhalo.";
            }
            else
            {
                SuccessMessage = "Položka bola pridaná do objednávky.";
                NewItem = new NewOrderItemModel(); // reset formulára
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri pridávaní položky: {ex.Message}";
        }

        await LoadDataAsync(id);
        return Page();
    }

    private void LoadRole()
    {
        var role = HttpContext.Session.GetString("USER_ROLE");
        IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);
    }

    private async Task LoadDataAsync(int id)
    {
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        // 1) detail objednávky (order + items)
        try
        {
            var resp = await _api.GetAsync($"/api/orders/{id}");
            if (!resp.IsSuccessStatusCode)
            {
                ErrorMessage = $"Nepodarilo sa načítať detail objednávky. Status {(int)resp.StatusCode}.";
                return;
            }

            var json = await resp.Content.ReadAsStringAsync();
            var detail = JsonSerializer.Deserialize<OrderDetailResponse>(json, options);

            if (detail == null)
            {
                ErrorMessage = "Chyba pri spracovaní odpovede z API.";
                return;
            }

            Order = detail.Order;
            Items = detail.Items ?? new List<OrderItemDto>();
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri načítaní detailu objednávky: {ex.Message}";
        }

        // 2) úlohy k objednávke
        try
        {
            var respTasks = await _api.GetAsync($"/api/orders/{id}/tasks");
            if (respTasks.IsSuccessStatusCode)
            {
                var jsonTasks = await respTasks.Content.ReadAsStringAsync();
                OrderTasks = JsonSerializer.Deserialize<List<TaskDto>>(jsonTasks, options)
                              ?? new List<TaskDto>();
            }
        }
        catch
        {
            // ak zlyhá, úlohy proste neukážeme
        }

        // 3) katalóg položiek pre admin formulár
        try
        {
            var respItems = await _api.GetAsync("/api/items");
            if (respItems.IsSuccessStatusCode)
            {
                var jsonItems = await respItems.Content.ReadAsStringAsync();
                ItemsCatalog = JsonSerializer.Deserialize<List<ItemDto>>(jsonItems, options)
                               ?? new List<ItemDto>();
            }
        }
        catch
        {
        }
    }
}
