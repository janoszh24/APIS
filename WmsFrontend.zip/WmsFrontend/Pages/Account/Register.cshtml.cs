using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Account;

public class RegisterModel : PageModel
{
    private readonly ApiClientService _api;

    public RegisterModel(ApiClientService api)
    {
        _api = api;
    }

    [BindProperty]
    public InputModel Input { get; set; } = new();

    public string? ErrorMessage { get; set; }
    public string? SuccessMessage { get; set; }

    public class InputModel
    {
        [Required]
        [Display(Name = "Meno")]
        public string Name { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Heslo")]
        public string Password { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Potvrdenie hesla")]
        [Compare(nameof(Password), ErrorMessage = "Heslá sa nezhodujú.")]
        public string ConfirmPassword { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Rola")]
        public string Role { get; set; } = "Worker";  // default

    }

    // DTO pre odpoveď, ak si ju chceš niekde použiť
    public class RegisterResponseDto
    {
        public int UserId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }

    public void OnGet()
    {
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        try
        {
            var body = new {
                name = Input.Name,
                email = Input.Email,
                password = Input.Password,
                role = Input.Role
            };


            var response = await _api.PostAsync("/api/register", body);

            if (!response.IsSuccessStatusCode)
            {
                var errJson = await response.Content.ReadAsStringAsync();

                try
                {
                    // FastAPI typicky vracia { "detail": "..." }
                    using var doc = JsonDocument.Parse(errJson);
                    if (doc.RootElement.TryGetProperty("detail", out var detailEl))
                    {
                        ErrorMessage = detailEl.GetString() ?? "Registrácia zlyhala.";
                    }
                    else
                    {
                        ErrorMessage = "Registrácia zlyhala.";
                    }
                }
                catch
                {
                    ErrorMessage = "Registrácia zlyhala.";
                }

                return Page();
            }


            var json = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var data = JsonSerializer.Deserialize<RegisterResponseDto>(json, options);

            SuccessMessage = "Účet bol vytvorený. Môžeš sa prihlásiť.";
            // necháme používateľa na stránke registrácie, ale formulár vyčistíme
            Input = new InputModel();

            return Page();
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri registrácii: {ex.Message}";
            return Page();
        }
    }
}
