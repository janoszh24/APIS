using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Account;

public class LoginModel : PageModel
{
    private readonly ApiClientService _api;

    public LoginModel(ApiClientService api)
    {
        _api = api;
    }

    [BindProperty]
    public InputModel Input { get; set; } = new();

    public string? ErrorMessage { get; set; }

    public class InputModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Heslo")]
        public string Password { get; set; } = string.Empty;
    }

    // DTO na deserializáciu odpovede z FastAPI
    public class LoginResponseDto
    {
        public string Token { get; set; } = string.Empty;
        public int UserId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }

    public IActionResult OnGet()
    {
        // ak je už prihlásený, pošli ho rovno na Dashboard
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (!string.IsNullOrEmpty(token))
        {
            return RedirectToPage("/Dashboard/Index");
        }

        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        try
        {
            // telo pre FastAPI /api/login – kľúče musia byť "email" a "password"
            var body = new
            {
                email = Input.Email,
                password = Input.Password
            };

            var response = await _api.PostAsync("/api/login", body);

            if (!response.IsSuccessStatusCode)
            {
                ErrorMessage = "Neplatné prihlasovacie údaje.";
                return Page();
            }

            var json = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var data = JsonSerializer.Deserialize<LoginResponseDto>(json, options);

            if (data == null || string.IsNullOrEmpty(data.Token))
            {
                ErrorMessage = "Chyba pri spracovaní odpovede zo servera.";
                return Page();
            }

            // uloženie do session – využívame v layoute a na autorizáciu
            HttpContext.Session.SetString("JWT_TOKEN", data.Token);
            HttpContext.Session.SetString("USER_ROLE", data.Role);
            HttpContext.Session.SetString("USER_ID", data.UserId.ToString());
            HttpContext.Session.SetString("USER_NAME", data.Name);

            return RedirectToPage("/Dashboard/Index");
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri prihlasovaní: {ex.Message}";
            return Page();
        }
    }
}
