using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Items;

public class IndexModel : PageModel
{
    private readonly ApiClientService _api;

    public IndexModel(ApiClientService api)
    {
        _api = api;
    }

    public List<ItemDto> Items { get; set; } = new();
    public string? ErrorMessage { get; set; }
    public string? SuccessMessage { get; set; }

    [BindProperty]
    public AddItemInput NewItem { get; set; } = new();

    // jednoduchý getter – či je aktuálny user Admin
    public bool IsAdmin =>
        string.Equals(HttpContext.Session.GetString("USER_ROLE"), "Admin",
            StringComparison.OrdinalIgnoreCase);

    public class AddItemInput
    {
        [Required]
        [Display(Name = "SKU")]
        public string SKU { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Názov")]
        public string Name { get; set; } = string.Empty;

        [Range(0.0, double.MaxValue)]
        [Display(Name = "Hmotnosť")]
        public double Weight { get; set; }

        [Required]
        [Display(Name = "Jednotka")]
        public string Unit { get; set; } = string.Empty;
    }

    public async Task<IActionResult> OnGetAsync()
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
            return RedirectToPage("/Account/Login");

        await LoadItemsAsync();
        return Page();
    }

    private async Task LoadItemsAsync()
    {
        try
        {
            var resp = await _api.GetAsync("/api/items");

            if (!resp.IsSuccessStatusCode)
            {
                ErrorMessage = $"Nepodarilo sa načítať produkty. Status {(int)resp.StatusCode}.";
                return;
            }

            var json = await resp.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

            Items = JsonSerializer.Deserialize<List<ItemDto>>(json, options)
                    ?? new List<ItemDto>();
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri načítaní produktov: {ex.Message}";
        }
    }

    // POST /Items?handler=Add
    public async Task<IActionResult> OnPostAddAsync()
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
            return RedirectToPage("/Account/Login");

        if (!IsAdmin)
        {
            ErrorMessage = "Nemáš oprávnenie pridávať produkty.";
            await LoadItemsAsync();
            return Page();
        }

        if (!ModelState.IsValid)
        {
            await LoadItemsAsync();
            return Page();
        }

        try
        {
            var body = new
            {
                sku = NewItem.SKU,
                name = NewItem.Name,
                weight = NewItem.Weight,
                unit = NewItem.Unit
            };

            var resp = await _api.PostAsync("/api/items", body);

            if (!resp.IsSuccessStatusCode)
            {
                ErrorMessage = $"Nepodarilo sa pridať produkt. Status {(int)resp.StatusCode}.";
            }
            else
            {
                SuccessMessage = "Produkt bol pridaný.";
                NewItem = new AddItemInput(); // vyčisti formulár
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri pridávaní produktu: {ex.Message}";
        }

        await LoadItemsAsync();
        return Page();
    }

    // POST /Items?handler=Delete&id=...
    public async Task<IActionResult> OnPostDeleteAsync(int id)
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
            return RedirectToPage("/Account/Login");

        if (!IsAdmin)
        {
            ErrorMessage = "Nemáš oprávnenie mazať produkty.";
            await LoadItemsAsync();
            return Page();
        }

        try
        {
            var resp = await _api.DeleteAsync($"/api/items/{id}");

            if (!resp.IsSuccessStatusCode)
            {
                ErrorMessage = $"Nepodarilo sa odstrániť produkt. Status {(int)resp.StatusCode}.";
            }
            else
            {
                SuccessMessage = "Produkt bol odstránený.";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Chyba pri mazaní produktu: {ex.Message}";
        }

        await LoadItemsAsync();
        return Page();
    }
}
