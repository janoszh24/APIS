using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WmsFrontend.Pages;

public class IndexModel : PageModel
{
    public IActionResult OnGet()
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");

        if (!string.IsNullOrEmpty(token))
        {
            return RedirectToPage("/Dashboard/Index");
        }

        return Page();
    }
}
