using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WmsFrontend.Models;
using WmsFrontend.Services;

namespace WmsFrontend.Pages.Dashboard;

public class IndexModel : PageModel
{
    private readonly ApiClientService _api;

    public IndexModel(ApiClientService api)
    {
        _api = api;
    }

    public bool IsAdmin { get; set; }

    public int TotalItems { get; set; }
    public int TotalOrders { get; set; }
    public int OpenOrders { get; set; }

    public int TotalTasks { get; set; }
    public int OpenTasks { get; set; }
    public int MyOpenTasks { get; set; }

    public int InventoryItemCount { get; set; }

    public List<OrderDto> RecentOrders { get; set; } = new();
    public List<TaskDto> MyTasksPreview { get; set; } = new();

    public string? ErrorMessage { get; set; }

    public async Task<IActionResult> OnGetAsync()
    {
        var token = HttpContext.Session.GetString("JWT_TOKEN");
        if (string.IsNullOrEmpty(token))
        {
            return RedirectToPage("/Account/Login");
        }

        var role = HttpContext.Session.GetString("USER_ROLE");
        IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);

        var userIdStr = HttpContext.Session.GetString("USER_ID");
        int.TryParse(userIdStr, out var userId);

        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        // 1) Produkty
        try
        {
            var respItems = await _api.GetAsync("/api/items");
            if (respItems.IsSuccessStatusCode)
            {
                var json = await respItems.Content.ReadAsStringAsync();
                var items = JsonSerializer.Deserialize<List<ItemDto>>(json, options) ?? new List<ItemDto>();
                TotalItems = items.Count;
            }
        }
        catch (Exception ex)
        {
            ErrorMessage ??= $"Chyba pri načítaní produktov: {ex.Message}";
        }

        // 2) Objednávky
        List<OrderDto> orders = new();
        try
        {
            var respOrders = await _api.GetAsync("/api/orders");
            if (respOrders.IsSuccessStatusCode)
            {
                var json = await respOrders.Content.ReadAsStringAsync();
                orders = JsonSerializer.Deserialize<List<OrderDto>>(json, options) ?? new List<OrderDto>();

                TotalOrders = orders.Count;
                OpenOrders = orders.Count(o => o.Status is "NEW" or "IN_PROGRESS");

                RecentOrders = orders
                    .OrderByDescending(o => o.CreatedAt)
                    .Take(5)
                    .ToList();
            }
        }
        catch (Exception ex)
        {
            ErrorMessage ??= $"Chyba pri načítaní objednávok: {ex.Message}";
        }

        // 3) Úlohy
        List<TaskDto> allTasks = new();
        try
        {
            if (IsAdmin)
            {
                var respTasksAdmin = await _api.GetAsync("/api/tasks-admin");
                if (respTasksAdmin.IsSuccessStatusCode)
                {
                    var json = await respTasksAdmin.Content.ReadAsStringAsync();
                    allTasks = JsonSerializer.Deserialize<List<TaskDto>>(json, options) ?? new List<TaskDto>();
                }
            }
            else if (userId > 0)
            {
                var respTasksUser = await _api.GetAsync($"/api/tasks/{userId}");
                if (respTasksUser.IsSuccessStatusCode)
                {
                    var json = await respTasksUser.Content.ReadAsStringAsync();
                    allTasks = JsonSerializer.Deserialize<List<TaskDto>>(json, options) ?? new List<TaskDto>();
                }
            }

            TotalTasks = allTasks.Count;
            OpenTasks = allTasks.Count(t => t.Status is "OPEN" or "IN_PROGRESS");

            if (userId > 0)
            {
                var myTasks = allTasks.Where(t => t.UserId == userId).ToList();
                MyOpenTasks = myTasks.Count(t => t.Status is "OPEN" or "IN_PROGRESS");

                MyTasksPreview = myTasks
                    .OrderBy(t => t.Status == "OPEN" ? 0 : 1)
                    .ThenByDescending(t => t.Id)
                    .Take(5)
                    .ToList();
            }
        }
        catch (Exception ex)
        {
            ErrorMessage ??= $"Chyba pri načítaní úloh: {ex.Message}";
        }

        // 4) Sklad (inventár)
        try
        {
            var respInv = await _api.GetAsync("/api/inventory");
            if (respInv.IsSuccessStatusCode)
            {
                var json = await respInv.Content.ReadAsStringAsync();
                var invRows = JsonSerializer.Deserialize<List<InventoryRowDto>>(json, options)
                              ?? new List<InventoryRowDto>();

                // počet rôznych skladových riadkov
                InventoryItemCount = invRows.Count;
            }
        }
        catch (Exception ex)
        {
            ErrorMessage ??= $"Chyba pri načítaní skladu: {ex.Message}";
        }

        return Page();
    }
}
