namespace WmsFrontend.Models;

public class OrderItemDto
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public int ItemId { get; set; }

    public int OrderedQty { get; set; }
    public int PickedQty { get; set; }

    public string ItemSku { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public int? WorkerId { get; set; }
}
