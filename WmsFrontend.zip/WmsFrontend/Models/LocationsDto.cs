namespace WmsFrontend.Models
{
    public class LocationsDto
    {
        public int Id { get; set; }
        public string Code { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Zone { get; set; } = string.Empty;
        public int Capacity { get; set; }
    }
}
