namespace WmsFrontend.Models;

public class OrderDto
{
    public int Id { get; set; }

    public string ExternalOrderId { get; set; } = string.Empty;

    public string Status { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; }

    public string CustomerName { get; set; } = string.Empty;

    public string CustomerAddress { get; set; } = string.Empty;
    public int? WorkerId { get; set; }
}
