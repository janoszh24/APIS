namespace WmsFrontend.Models;

public class TaskDto
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public int UserId { get; set; }

    public string Type { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;

    public DateTime? StartedAt { get; set; }
    public DateTime? FinishedAt { get; set; }

    public double? EstimatedDurationMin { get; set; }
    public double? ActualDurationMin { get; set; }
}
