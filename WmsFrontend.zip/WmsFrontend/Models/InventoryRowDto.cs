namespace WmsFrontend.Models
{
    public class InventoryRowDto
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; } = string.Empty;

        public int LocationId { get; set; }
        public string LocationCode { get; set; } = string.Empty;

        public int Quantity { get; set; }
    }
}
