namespace WmsFrontend.Models;

public class ItemDto
{
    public int Id { get; set; }
    public string SKU { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public double Weight { get; set; }
    public string Unit { get; set; } = string.Empty;
}
