namespace WmsFrontend.Models;

public class InventoryItemDto
{
    public int Id { get; set; }
    public int ItemId { get; set; }
    public int LocationId { get; set; }
    public int Quantity { get; set; }

    // Naplníme podľa ItemId / LocationId, aby UI vedelo ukázať pomenovania
    public string ItemName { get; set; } = string.Empty;
    public string LocationName { get; set; } = string.Empty;
    public string LocationCode { get; set; } = string.Empty;

}
