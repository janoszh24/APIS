namespace WmsFrontend.Models;

public class OrderDetailResponse
{
    public OrderDto Order { get; set; } = new();
    public List<OrderItemDto> Items { get; set; } = new();
    public int? WorkerId { get; set; }
}
