using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace WmsFrontend.Services;

public class ApiClientService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IHttpContextAccessor _context;

    public ApiClientService(IHttpClientFactory httpClientFactory, IHttpContextAccessor context)
    {
        _httpClientFactory = httpClientFactory;
        _context = context;
    }

    private HttpClient CreateClient()
    {
        var client = _httpClientFactory.CreateClient("ApiClient");

        // Ak máme JWT token, pridáme ho do hlavičky
        var token = _context.HttpContext?.Session.GetString("JWT_TOKEN");
        if (!string.IsNullOrEmpty(token))
        {
            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);
        }

        return client;
    }

    public async Task<HttpResponseMessage> GetAsync(string url)
        => await CreateClient().GetAsync(url);

    public async Task<HttpResponseMessage> PostAsync(string url, object body)
    {
        var json = JsonSerializer.Serialize(body);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        return await CreateClient().PostAsync(url, content);
    }

    public async Task<HttpResponseMessage> DeleteAsync(string url)
    {
        return await CreateClient().DeleteAsync(url);
    }


    

}
