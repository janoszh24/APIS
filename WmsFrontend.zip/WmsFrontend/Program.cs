using WmsFrontend.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();

// 1) Načítaj URL na ML API z konfigurácie
var mlApiBaseUrl = builder.Configuration["MlApi:BaseUrl"] ?? "http://localhost:8000";

// 2) HttpClient, ktorý bude volať FastAPI
builder.Services.AddHttpClient("ApiClient", client =>
{
    client.BaseAddress = new Uri(mlApiBaseUrl);
});

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(1);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ApiClientService>();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.MapRazorPages();
app.Run();
